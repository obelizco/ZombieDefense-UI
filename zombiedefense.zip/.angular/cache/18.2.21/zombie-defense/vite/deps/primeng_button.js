import {
  Button,
  ButtonClasses,
  ButtonDirective,
  ButtonIcon,
  ButtonLabel,
  ButtonModule,
  ButtonStyle
} from "./chunk-JTEEHJDZ.js";
import "./chunk-J5UAURQH.js";
import "./chunk-SCBWMRBH.js";
import "./chunk-5G7WYC4N.js";
import "./chunk-DJGQ4GW6.js";
import "./chunk-W67TBKJO.js";
import "./chunk-PMU6GHS4.js";
import "./chunk-WERJMNXE.js";
import "./chunk-G6JPFBYE.js";
import "./chunk-64LZZIVC.js";
import "./chunk-QMRUVJU3.js";
import "./chunk-WDMUDEB6.js";
export {
  Button,
  ButtonClasses,
  ButtonDirective,
  ButtonIcon,
  ButtonLabel,
  ButtonModule,
  ButtonStyle
};
//# sourceMappingURL=primeng_button.js.map
