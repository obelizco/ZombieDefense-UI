import {
  Paginator,
  PaginatorClasses,
  PaginatorModule,
  PaginatorStyle
} from "./chunk-4XS2UCVA.js";
import "./chunk-HC5ZY5YS.js";
import "./chunk-F62OGWJW.js";
import "./chunk-NLDY2K4C.js";
import "./chunk-U7D4JXQ4.js";
import "./chunk-SJMWJFBB.js";
import "./chunk-SXNHILPH.js";
import "./chunk-J5UAURQH.js";
import "./chunk-5G7WYC4N.js";
import "./chunk-SKRJJFZ3.js";
import "./chunk-XGGRNLSP.js";
import "./chunk-2ZXM7VXU.js";
import "./chunk-DJGQ4GW6.js";
import "./chunk-W67TBKJO.js";
import "./chunk-PMU6GHS4.js";
import "./chunk-WERJMNXE.js";
import "./chunk-G6JPFBYE.js";
import "./chunk-64LZZIVC.js";
import "./chunk-QMRUVJU3.js";
import "./chunk-WDMUDEB6.js";
export {
  Paginator,
  PaginatorClasses,
  PaginatorModule,
  PaginatorStyle
};
//# sourceMappingURL=primeng_paginator.js.map
