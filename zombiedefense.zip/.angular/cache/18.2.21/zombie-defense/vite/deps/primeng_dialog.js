import {
  Dialog,
  DialogClasses,
  DialogModule,
  DialogStyle
} from "./chunk-WTVNNTYW.js";
import "./chunk-A2J6GUVK.js";
import "./chunk-JTEEHJDZ.js";
import "./chunk-J5UAURQH.js";
import "./chunk-SCBWMRBH.js";
import "./chunk-5G7WYC4N.js";
import "./chunk-XGGRNLSP.js";
import "./chunk-2ZXM7VXU.js";
import "./chunk-DJGQ4GW6.js";
import "./chunk-W67TBKJO.js";
import "./chunk-PMU6GHS4.js";
import "./chunk-WERJMNXE.js";
import "./chunk-G6JPFBYE.js";
import "./chunk-64LZZIVC.js";
import "./chunk-QMRUVJU3.js";
import "./chunk-WDMUDEB6.js";
export {
  Dialog,
  DialogClasses,
  DialogModule,
  DialogStyle
};
//# sourceMappingURL=primeng_dialog.js.map
