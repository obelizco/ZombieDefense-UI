import {
  PRIME_NG_CONFIG,
  PrimeNG,
  ThemeProvider,
  providePrimeNG
} from "./chunk-WERJMNXE.js";
import "./chunk-G6JPFBYE.js";
import "./chunk-64LZZIVC.js";
import "./chunk-QMRUVJU3.js";
import "./chunk-WDMUDEB6.js";
export {
  PRIME_NG_CONFIG,
  PrimeNG,
  ThemeProvider,
  providePrimeNG
};
//# sourceMappingURL=primeng_config.js.map
