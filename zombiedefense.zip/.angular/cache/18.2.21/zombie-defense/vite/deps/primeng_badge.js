import {
  Badge,
  BadgeClasses,
  BadgeDirective,
  BadgeModule,
  BadgeStyle
} from "./chunk-SCBWMRBH.js";
import "./chunk-PMU6GHS4.js";
import "./chunk-WERJMNXE.js";
import "./chunk-G6JPFBYE.js";
import "./chunk-64LZZIVC.js";
import "./chunk-QMRUVJU3.js";
import "./chunk-WDMUDEB6.js";
export {
  Badge,
  BadgeClasses,
  BadgeDirective,
  BadgeModule,
  BadgeStyle
};
//# sourceMappingURL=primeng_badge.js.map
