import {
  Chip,
  ChipClasses,
  ChipModule,
  ChipStyle
} from "./chunk-GA2GTX5K.js";
import "./chunk-W67TBKJO.js";
import "./chunk-PMU6GHS4.js";
import "./chunk-WERJMNXE.js";
import "./chunk-G6JPFBYE.js";
import "./chunk-64LZZIVC.js";
import "./chunk-QMRUVJU3.js";
import "./chunk-WDMUDEB6.js";
export {
  Chip,
  ChipClasses,
  ChipModule,
  ChipStyle
};
//# sourceMappingURL=primeng_chip.js.map
