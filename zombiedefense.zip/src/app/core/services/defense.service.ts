import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { DefenseResult } from '../interfaces/defense-result.model';
import { environment } from '../../../environments/environment';

@Injectable({ providedIn: 'root' })
export class DefenseService {
  private readonly apiUrl = environment.apiUrl;
  public header= new HttpHeaders().set("X-API-KEY",environment.x_apy_key);
  constructor(private http: HttpClient) {}

  getOptimalStrategy(bullets: number, secondsAvailable: number): Observable<DefenseResult> {
    return this.http.get<DefenseResult>(
      `${this.apiUrl}/optimal-strategy?bullets=${bullets}&secondsAvailable=${secondsAvailable}`,{headers:this.header}
    );
  }
}