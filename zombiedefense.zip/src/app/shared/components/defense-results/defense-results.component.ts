import { Component, Input } from '@angular/core';
import { DefenseResult } from '../../../core/interfaces/defense-result.model';

@Component({
  selector: 'app-defense-results',
  templateUrl: './defense-results.component.html'
})
export class DefenseResultsComponent {
  @Input() result!: DefenseResult;
}