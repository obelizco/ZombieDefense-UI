export const environment = {
  production: true,
  apiUrl: 'https://localhost:7259/defense',
  x_apy_key:'ZombieApiKEY'
};