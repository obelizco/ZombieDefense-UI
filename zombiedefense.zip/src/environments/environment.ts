export const environment = {
  production: false,
  apiUrl: 'https://localhost:7259/defense',
  x_apy_key:'ZombieApiKEY'
};